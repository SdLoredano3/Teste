# English Conversação — projeto Android

Projeto-fonte nativo em Kotlin, com interface simples para praticar frases em inglês.

## O que faz
- Botão de microfone para reconhecer uma frase em português.
- Tradução online de português para inglês via API pública MyMemory.
- Leitura da tradução em voz alta pelo Android Text-to-Speech.
- Botões para ativar/parar uma notificação de segundo plano.

## Limitações
- Este ZIP contém código-fonte, **não um APK já compilado**.
- A tradução usa um serviço de tradução online, não uma IA conversacional. A disponibilidade e os limites do serviço podem mudar.
- O serviço de segundo plano é apenas um marcador com notificação: **não escuta continuamente**. O Android restringe o acesso ao microfone em segundo plano. Escuta contínua exigiria um desenho próprio com controles visíveis, permissões, testes e tratamento das restrições da versão do Android.
- Reconhecimento de voz pode ser enviado ao provedor de voz configurado no aparelho. A frase também é enviada ao serviço de tradução online. Não fale dados sensíveis.
- Para IA generativa real, use um backend seguro. Não inclua uma chave secreta de API dentro do APK.

## Como gerar e instalar APK
1. Instale Android Studio em um computador.
2. Extraia este ZIP.
3. No Android Studio, selecione Open e escolha a pasta `English_Conversation_Android`.
4. Aguarde a sincronização do Gradle.
5. Conecte o celular com depuração USB ou use um emulador e clique em Run.
6. Para criar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
7. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.
8. Transfira o APK para o celular, abra-o e autorize a instalação dessa fonte, se solicitado.

## Privacidade
A frase reconhecida é enviada ao serviço de tradução online para ser traduzida. Use frases comuns de prática, não senhas, dados bancários ou informações privadas.
