package com.example.englishconversation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

// Este serviço mostra uma notificação persistente, mas não mantém o microfone
// continuamente aberto. O Android limita escuta contínua em segundo plano.
class ListeningService : Service() {
    private val channelId = "english_conversation_background"
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "English Conversação", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        startForeground(7, makeNotification())
    }

    private fun makeNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 8, Intent(this, ListeningService::class.java).setAction("STOP"),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("English Conversação")
                .setContentText("Modo segundo plano ativo.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .addAction(Notification.Action.Builder(null, "Parar", stopIntent).build())
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("English Conversação")
                .setContentText("Modo segundo plano ativo.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_NOT_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
