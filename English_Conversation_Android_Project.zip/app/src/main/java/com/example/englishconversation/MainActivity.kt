package com.example.englishconversation

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var heard: TextView
    private lateinit var translated: TextView
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val speechRequest = 101
    private val permissionRequest = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF7F7F7.toInt())
        }
        val title = TextView(this).apply {
            text = "English Conversação"; textSize = 25f
            setTextColor(0xFF171717.toInt()); gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Toque em Falar e diga uma frase em português."
            textSize = 14f; setTextColor(0xFF555555.toInt()); gravity = Gravity.CENTER
            setPadding(0, 14, 0, 18)
        }
        val mic = Button(this).apply {
            text = "🎙  Falar"; textSize = 19f
            setOnClickListener { startSpeechRecognition() }
        }
        heard = TextView(this).apply {
            text = "Você disse: —"; textSize = 17f; setTextColor(0xFF202020.toInt())
            setPadding(0, 24, 0, 12)
        }
        translated = TextView(this).apply {
            text = "Em inglês: —"; textSize = 22f; setTextColor(0xFF146C43.toInt())
            setPadding(0, 8, 0, 18)
        }
        val speak = Button(this).apply {
            text = "🔊 Ouvir inglês"
            setOnClickListener {
                val phrase = translated.text.toString().removePrefix("Em inglês: ").trim()
                if (phrase.isNotBlank() && phrase != "—") speakEnglish(phrase)
            }
        }
        val background = Button(this).apply {
            text = "Ativar modo segundo plano"
            setOnClickListener {
                if (hasAudioPermission()) {
                    val i = Intent(this@MainActivity, ListeningService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                    status.text = "Notificação de segundo plano ativada. A escuta contínua não fica ligada neste protótipo."
                } else requestPermissionsIfNeeded()
            }
        }
        val stop = Button(this).apply {
            text = "Parar modo segundo plano"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ListeningService::class.java))
                status.text = "Modo segundo plano parado."
            }
        }
        listOf(title, status, mic, heard, translated, speak, background, stop).forEach {
            root.addView(it, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val note = TextView(this).apply {
            text = "A tradução usa um serviço online gratuito, não uma IA conversacional. Não diga senhas ou dados pessoais."
            textSize = 12f; setTextColor(0xFF666666.toInt()); setPadding(0, 20, 0, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequest)
    }

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startSpeechRecognition() {
        if (!hasAudioPermission()) { requestPermissionsIfNeeded(); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale uma frase em português")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { Toast.makeText(this, "Reconhecimento de voz indisponível neste aparelho.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Legacy speech activity callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (phrase.isNotBlank()) {
                heard.text = "Você disse: $phrase"
                status.text = "Buscando tradução online…"
                translate(phrase)
            }
        }
    }

    private fun translate(phrase: String) {
        thread {
            try {
                val q = URLEncoder.encode(phrase, "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=pt-BR|en-GB")
                val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000 }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val result = JSONObject(body).getJSONObject("responseData").optString("translatedText").trim()
                runOnUiThread {
                    if (result.isNotBlank()) {
                        translated.text = "Em inglês: $result"
                        status.text = "Tradução recebida."
                        speakEnglish(result)
                    } else status.text = "Não foi possível traduzir. Tente outra frase."
                }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Sem conexão ou serviço indisponível. Tente novamente." }
            }
        }
    }

    private fun speakEnglish(text: String) {
        if (!ttsReady) { status.text = "A voz ainda está iniciando."; return }
        tts.language = Locale.UK
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "english-phrase")
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.UK
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
